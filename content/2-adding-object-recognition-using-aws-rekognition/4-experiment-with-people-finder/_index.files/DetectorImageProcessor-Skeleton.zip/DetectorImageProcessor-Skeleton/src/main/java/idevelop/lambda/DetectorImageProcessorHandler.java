package idevelop.lambda;

import java.math.BigDecimal;
import java.util.List;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.Attribute;
import com.amazonaws.services.rekognition.model.DetectFacesRequest;
import com.amazonaws.services.rekognition.model.DetectFacesResult;
import com.amazonaws.services.rekognition.model.Emotion;
import com.amazonaws.services.rekognition.model.FaceDetail;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.S3Object;
import com.amazonaws.services.rekognition.model.SearchFacesByImageRequest;
import com.amazonaws.services.rekognition.model.SearchFacesByImageResult;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.internal.DeleteObjectsResponse;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.DeleteObjectsResult;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;

public class DetectorImageProcessorHandler implements RequestHandler<S3Event, Void> 
{
	private AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
	private DynamoDB dynamoDB = new DynamoDB(client);
	private AmazonS3 s3 = AmazonS3ClientBuilder.standard().build();
	private AmazonRekognition rekognition = AmazonRekognitionClientBuilder.standard().build();
	private String collectionId = System.getenv("REKOGNITION_COLLECTION_ID");
	private String ddbTableName = System.getenv("DDB_TABLENAME_KNOWN_FACES");
	
	private final float FACE_MATCH_THRESHOLD = 90.0f;
	
	public Void handleRequest(S3Event event, Context context) 
	{				
		LambdaLogger logger = context.getLogger();
		
		logger.log("Starting " + this.getClass().getName() + " Lambda\n");
		
		if ( collectionId == null || collectionId == "" )
		{
			System.out.println("REKOGNITION_COLLECTION_ID envVar not set!");
		}
		else
		if ( ddbTableName == null || ddbTableName == "" )
		{
			System.out.println("DDB_TABLENAME_KNOWN_FACES envVar not set!");
		}
		else
		{
			try
			{			            
		        String bucket = event.getRecords().get(0).getS3().getBucket().getName();
		        String key = event.getRecords().get(0).getS3().getObject().getKey();
	
		        System.out.println(String.format(
		                "Processing for %s/%s", bucket, key));
	
		        //
		        // Get the metadata about the detection - used to update DDB
		        //
		        ObjectMetadata s3Metadata = s3.getObjectMetadata(new GetObjectMetadataRequest(bucket, key));
		        String detectorLocation = s3Metadata.getUserMetaDataOf("idevelop-location");
		        String detectionDate = s3Metadata.getUserMetaDataOf("idevelop-date");
		        
		        
		        //************************************************************************************
		        // TODO:
		        //
		        // 1. Detect faces in the image. Assume only 1 is provided, so just take the first.
		        //    You can use the provided getImageUtil() function to create a suitable Image object
		        //    for Rekognition
		        //
		        // 2. For the first face in the result set, get the emotions collection. Iterate through
		        //    the collection and generate a string containing all the emotions that are present.
		        //    If there are no emotions, set an emotion string of 'Indeterminate'
		        //    Only take emotions that have a confidence factor > 30
		        //
		        // 3. Search the Rekognition collection for matches for the face, using searchFacesByImage().
		        //    Use the FACE_MATCH_THRESHOLD provided
		        //
		        // 4. If you find a match, use the faceId of the match to update the DynamoDB table. Since
		        //    the order of processing the images in S3 is indeterminate, you should not update 
		        //    the DynamoDB table if the image is older than the last update to DynamoDB. You can use
		        //    the detectionDate variable extracted from the object metadata above for that purpose
		        //
		        //
		        //************************************************************************************
		        
		        
                // Delete the original image
                System.out.println("Deleting the original file...");
                s3.deleteObjects(
                		new DeleteObjectsRequest(bucket)
                			.withKeys(key)
                			);
                System.out.println("     done");
		        
			}
			catch(Exception e)
			{
				String errorMessage = String.format(
		                "Error processing image"
		                );
				
				System.out.println(errorMessage);
				System.out.println(e.getMessage());
			}
			finally
			{
				System.out.println("Processing ends");
			}	
		}
		
		return null;		
	}

	private static Image getImageUtil(String bucket, String key) 
	{
       return new Image()
    		  	.withS3Object(new S3Object()
            .withBucket(bucket)
            .withName(key));
	}
}
