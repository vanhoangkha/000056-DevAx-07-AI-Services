package idevelop.samples.test;

import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.junit.MockitoJUnitRunner;

import com.amazonaws.services.polly.model.Voice;

import idevelop.samples.PollyManager;

@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestSuite {

	static String voiceName = "Nicole";
	static Voice voice = null;
		
	@BeforeClass
    public static void setUp() {
		
		System.out.println("==================================");
		System.out.println("Starting Test Suite");
		System.out.println("==================================\n");
		System.out.println("Testing " + PollyManager.class.getName());
		
        PollyManager pollyManager = new PollyManager();
        System.out.println("Looking up voice details for " + voiceName);
        voice = pollyManager.GetVoiceByName(voiceName);
        System.out.println("Got voice details: " + voice.getName() + "  [" + voice.getGender() + "] " + voice.getLanguageName());
    }
	
    @Test
    public void test_A_ListVoices() {

    		PollyManager pollyManager = new PollyManager();
    	
	    	try
	    	{
	    		pollyManager.ListVoices();
	    }
	    	catch(Exception ex)
	    	{
	    		System.out.println(ex.getMessage());
	    		throw ex;
	    	}
    }

    @Test
    public void test_B_Synthesise() throws Exception {

    		PollyManager pollyManager = new PollyManager();
    	
	    	try
	    	{
	    		pollyManager.render("Hello, this is a test. If you can hear this, then your connection to Amazon Polly is working as expected!", voice);
	    }
	    	catch(Exception ex)
	    	{
	    		System.out.println(ex.getMessage());
	    		throw ex;
	    	}
    }
}
