package idevelop.samples.models;

import java.util.List;

public class PollySpeechMarkers {

	private List<PollySpeechMarker> speechMarkers;

	public List<PollySpeechMarker> getSpeechMarkers() {
		return speechMarkers;
	}

	public void setSpeechMarkers(List<PollySpeechMarker> speechMarkers) {
		this.speechMarkers = speechMarkers;
	}
}
