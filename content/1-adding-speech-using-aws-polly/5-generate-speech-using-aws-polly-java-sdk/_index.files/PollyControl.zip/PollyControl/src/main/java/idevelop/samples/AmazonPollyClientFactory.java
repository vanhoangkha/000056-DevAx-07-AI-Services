package idevelop.samples;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.polly.AmazonPolly;
import com.amazonaws.services.polly.AmazonPollyClientBuilder;

public class AmazonPollyClientFactory {

	public static AmazonPolly getClient() {

		AmazonPolly polly = null;

		/*
	     * The ProfileCredentialsProvider will return your [default]
	     * credential profile by reading from the credentials file located at
	     * (~/.aws/credentials).
	     */
	    AWSCredentials credentials = null;
	    try {
	    		credentials = new ProfileCredentialsProvider("aws-lab-env").getCredentials();	    		
	    } catch (Exception e) {
	        throw new AmazonClientException(
	                "Cannot load the credentials from the credential profiles file. " +
	                "Please make sure that your credentials file is at the correct " +
	                "location (~/.aws/credentials), and is in valid format.",
	                e);
	    }

	    polly = AmazonPollyClientBuilder
	    		.standard()
	    		.withRegion(Regions.US_EAST_1)
	    		.withCredentials(new AWSStaticCredentialsProvider(credentials))
	    		.build();

	    return polly;
	}
}
