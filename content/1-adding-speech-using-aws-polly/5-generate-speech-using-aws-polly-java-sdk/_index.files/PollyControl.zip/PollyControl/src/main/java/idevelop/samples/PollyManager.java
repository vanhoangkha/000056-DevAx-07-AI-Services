package idevelop.samples;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import com.amazonaws.services.polly.AmazonPolly;
import com.amazonaws.services.polly.model.DescribeVoicesRequest;
import com.amazonaws.services.polly.model.DescribeVoicesResult;
import com.amazonaws.services.polly.model.OutputFormat;
import com.amazonaws.services.polly.model.SpeechMarkType;
import com.amazonaws.services.polly.model.SynthesizeSpeechRequest;
import com.amazonaws.services.polly.model.SynthesizeSpeechResult;
import com.amazonaws.services.polly.model.Voice;
import com.fasterxml.jackson.databind.ObjectMapper;

import idevelop.samples.models.PollySpeechMarker;
import idevelop.samples.models.PollySpeechMarkers;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
import javazoom.jl.player.advanced.PlaybackEvent;
import javazoom.jl.player.advanced.PlaybackListener;

public class PollyManager {
	
	private AmazonPolly polly = null;
	private boolean stillPlaying = false;
	private long lastPosition = -1;
	private int wordsRendered = 0;
	private String lastWordRendered = "";
	private long start_time = System.currentTimeMillis();
	private PollySpeechMarkers speechMarkers = null;
	
	public PollyManager()
	{
		this.polly = AmazonPollyClientFactory.getClient();
	}
	
	public Voice GetVoiceByName(String voiceName) 
	{       
		Voice result = null;
		DescribeVoicesRequest describeVoicesRequest = new DescribeVoicesRequest();

		// Synchronously ask Amazon Polly to describe available TTS voices.
		DescribeVoicesResult describeVoicesResult = polly.describeVoices(describeVoicesRequest);
		
        for (Voice voice : describeVoicesResult.getVoices()) {
        		if ( voice.getName().equalsIgnoreCase(voiceName) )
        		{
        			result = voice;
        		}
        }    
        
        return result;
    }

	public void ListVoices() 
	{       
		DescribeVoicesRequest describeVoicesRequest = new DescribeVoicesRequest();

		// Synchronously ask Amazon Polly to describe available TTS voices.
		DescribeVoicesResult describeVoicesResult = polly.describeVoices(describeVoicesRequest);
		
        for (Voice voice : describeVoicesResult.getVoices()) {
            System.out.println(voice.getName() + "  [" + voice.getGender() + "] " + voice.getLanguageName());
        }    
    }
	
	public InputStream synthesize(String text, Voice voice, OutputFormat format) throws IOException 
	{
		SynthesizeSpeechRequest synthReq = new SynthesizeSpeechRequest()
													.withText(text)
													.withVoiceId(voice.getId())
													.withOutputFormat(format);
		
		SynthesizeSpeechResult synthRes = polly.synthesizeSpeech(synthReq);

		return synthRes.getAudioStream();
	} 
	
	public PollySpeechMarkers GetSpeechMarkers(String text, Voice voice) throws IOException 
	{
		//
		// START: Dummy implementation
		//
		// This is a dummy implementation as if the data were returned from
		// a call to Polly::synthesiseSpeech() in order to return speech marks
		//
		// Your task is to impement the actual call to synthesiseSpeech and
		// obtain the speech marks for real
		//
		String dummySpeechMarks = "{\"time\":1,\"type\":\"word\",\"start\":0,\"end\":100,\"value\":\"You need to implement the call to SynthesizeSpeechRequest() in GetSpeechMarkers()\"}\n";
		InputStream dummyStream = new ByteArrayInputStream(
				dummySpeechMarks.getBytes(StandardCharsets.UTF_8.name())
				); 
		SynthesizeSpeechResult synthRes = new SynthesizeSpeechResult().withAudioStream(dummyStream);
		//
		// END: Dummy implementation
		//
		
		
		//
		// Don't change the code below :)
		//
		int ch;
		StringBuilder sb = new StringBuilder("{\"speechMarkers\": [");
		while((ch = synthRes.getAudioStream().read()) != -1)
		    sb.append((char)ch);
		
		String json = sb.toString();
		System.out.println(json);
		json = json.substring(0, json.length()-1).replaceAll("\\n|\\s{2,}", ",") + "]}";
		
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(json, PollySpeechMarkers.class);
	} 
	
	public void render(String text, Voice voice) throws IOException, JavaLayerException
	{
		// Determine the timings for the words in the text we will render
		speechMarkers = GetSpeechMarkers(text, voice);
		
		// Synthesise the audio from text
		InputStream speechStream = synthesize(text, voice, OutputFormat.Mp3);

		// Create an MP3 player to render the audio locally
		AdvancedPlayer player = new AdvancedPlayer(speechStream,
				javazoom.jl.player.FactoryRegistry.systemRegistry().createAudioDevice());

		// Simple thread to run in sync with the audio output
		Thread threadPosition = new Thread(new Runnable() {

		    @Override
		    public void run() {

		    		while(stillPlaying)
		    		{
				    	long currentPosition = System.currentTimeMillis() - start_time;
				    	if ( lastPosition != currentPosition )
				    	{				    		
				    		String thisWord = GetWordToRenderAtPosition(currentPosition);
				    		if ( !lastWordRendered.equalsIgnoreCase(thisWord) )
				    		{
				    			System.out.print(thisWord + " ");
				    			lastWordRendered = thisWord;
				    			
				    			if ( ++wordsRendered % 12 == 0)
				    				System.out.println("");
				    		}
				    	}
				    	lastPosition = currentPosition;
		    		}
		    }
		    
		});

		player.setPlayBackListener(new PlaybackListener() 
		{
			@Override
			public void playbackStarted(PlaybackEvent evt) 
			{
				System.out.println("Playback started:");
				
				stillPlaying = true;
				start_time = System.currentTimeMillis();
				lastPosition = -1;
				lastWordRendered = "";
				wordsRendered = 0;
				
				threadPosition.start();
			}
			
			@Override
			public void playbackFinished(PlaybackEvent evt) {
				stillPlaying = false;
				System.out.println("\n\nPlayback finished");				
			}
		});
		
		
		// play it!
		player.play();
	}
	
	private String GetWordToRenderAtPosition(long position)
	{
		String result = "";
		String wordPrevious = "";
		
		for (PollySpeechMarker item : this.speechMarkers.getSpeechMarkers()) {
		
			if ( position > item.getTime() )
			{
				wordPrevious = item.getValue();
				result = item.getValue();
			}
			else
			{
				result = wordPrevious;
			}
		}
		
		return result;
	}

}


