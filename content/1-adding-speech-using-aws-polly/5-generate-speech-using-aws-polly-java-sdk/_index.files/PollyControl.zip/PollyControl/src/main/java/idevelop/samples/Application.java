package idevelop.samples;

import java.util.Scanner;

import com.amazonaws.services.polly.model.Voice;

public class Application {

	public static int menu(Voice voice) {
	
	    int selection;
	    Scanner input = new Scanner(System.in);

        System.out.println("-------------------------");
        System.out.println("Main Menu");
        System.out.println("-------------------------\n");
        System.out.println("0 - Quit");
        System.out.println("1 - What is Amazon Polly?");
        System.out.println("2 - List Voices");
        System.out.println("3 - Set Voice (" + voice.getName() + ")");
        System.out.println("4 - Synthesise Speech");
        	
	    selection = input.nextInt();
	    return selection;    
	}
	
	public static void main(String[] args) {

		
        System.out.println("===========================================");
        System.out.println("Welcome to iDevelop<AWS>!");
        System.out.println("===========================================");
        System.out.println("\nPollyControl starting!\n");
        
        PollyManager pollyManager = new PollyManager();
        String voiceName = "Russell";
        
        try
        {
	        System.out.println("Looking up voice details for " + voiceName);
	        Voice voice = pollyManager.GetVoiceByName(voiceName);	        
        
			int menuChoice = -1;
			
			while (menuChoice != 0) {
				
				try
				{
					menuChoice = menu(voice);
					
					Scanner input = new Scanner(System.in);
					
					switch ( menuChoice ) {
								
						case 0:
							System.out.println("\nExiting!");
							break;
								
						case 1:
							System.out.println("Starting demo...");
							pollyManager.render("Amazon Polly is a cloud service that converts text into lifelike speech. You can use Amazon Polly to develop applications that increase engagement and accessibility. Amazon Polly supports multiple languages and includes a variety of lifelike voices, so you can build speech-enabled applications that work in multiple locations and use the ideal voice for your customers. With Amazon Polly, you only pay for the text you synthesize. You can also cache and replay Amazon Polly's generated speech at no additional cost.", voice);
							break;
							
						case 2:
							System.out.print("\nListing voices...");
							pollyManager.ListVoices();
							break;
					
						case 3:
							System.out.print("\nPlease enter voice to use: ");
							voiceName = input.nextLine();
					        System.out.println("Looking up voice details for " + voiceName);
					        voice = pollyManager.GetVoiceByName(voiceName);
							System.out.println("\nOk, voice set to " + voice.getName());
							break;
	
						case 4:
							System.out.print("\nPlease enter text to synthesise: ");
							pollyManager.render(input.nextLine(), voice);
							break;
	
					}
					
				}
				catch(Exception ex)
				{
					System.out.println("\n===========================================");
					System.out.println("EXCEPTION: " + ex.getMessage());
					System.out.println("===========================================\n");
				}
							
			}
        }
		catch(Exception ex)
		{
			System.out.println("\n===========================================");
			System.out.println("EXCEPTION: " + ex.getMessage());
			System.out.println("===========================================\n");
		}
        
    }
}

