var config = {
    cognitoIdentityPoolId : "ap-southeast-1:abc8feaf-8620-4cf2-b5fb-88176aad6f15",
    detectorUploadBucket: "module7-1-s3bucketdetectoruploads083dd69a-10f80vjnwomdx",
    ddbTableName : "module7-1-DDBTable2F2A2F95-8XJZXHQJCDAN",
    rekognitionCollectionId : "iDevelopKnownFaces",
    faceMatchThreshold : 90,
    region : "ap-southeast-1"
}