$(document).ready(function ($) {

    $("#clear-collection").click(function (event) {
        event.preventDefault();

        updateTextArea($('#response-area-clear-result'), "Submitting DELETE request...");


        var params =
        {
            CollectionId: config.rekognitionCollectionId
        };

        new AWS.Rekognition().deleteCollection(params, function (err, data) {
            if (err) {
                updateTextArea($('#response-area-clear-result'), JSON.stringify(err));
            }

            updateTextArea($('#response-area-clear-result'), "Delete OK - creating collection...");


            new AWS.Rekognition().createCollection(params, function (err, data) {
                if (err) {
                    updateTextArea($('#response-area-clear-result'), JSON.stringify(err));
                }
                else {
                    updateTextArea($('#response-area-clear-result'), JSON.stringify(data));
                }
            });

        });
    });

    $("#webcam-capture-associate").attr("disabled", "disabled");
    $("#webcam-start-associate").click(function (event) {
        event.preventDefault();
        webcamElement = document.getElementById('webcamCollection');
        canvasElement = document.getElementById('canvas');
        webcam = new Webcam(webcamElement, 'user', canvasElement, null);

        webcam.start()
            .then(result => {
                console.log("webcam started");
                setTimeout(recogniseFace, 1000);
            })
            .catch(err => {
                console.log(err);
            });

        $("#webcam-container").show();
        $("#webcam-start-associate").attr("disabled", "disabled");
        $("#webcam-capture-associate").removeAttr("disabled");
    });

    $("#webcam-capture-associate").click(function (event) {

        event.preventDefault();

        //
        // If all fields have data, we can grab the image
        //
        $("#webcam-capture-associate").attr("disabled", "disabled");
        var readyToSubmit = (
            $("#associate-favouriteAnimal").val() != "" &&
            $("#associate-favouriteAnimal").val() != null &&
            $("#associate-hometown").val() != "" &&
            $("#associate-username").val() != ""
        );

        if (readyToSubmit) {
            updateTextArea($('#response-area-associate-result'), "Submitting image...");

         //  Webcam.snap(function (data_uri) {
            data_uri = webcam.snap();
               // Webcam.freeze();

                var params =
                {
                    CollectionId: config.rekognitionCollectionId,
                    DetectionAttributes: ["ALL", "DEFAULT"],
                    ExternalImageId: "" + new Date().getTime(),
                    Image:
                    {
                        Bytes: dataURItoBlob(data_uri)
                    }
                };

                new AWS.Rekognition().indexFaces(params, function (err, data) {
                    if (err) {
                        updateTextArea($('#response-area-associate-result'), JSON.stringify(err));
                    }
                    else {
                        updateTextArea($('#response-area-associate-result'), JSON.stringify(data));
                    }

                  //  Webcam.reset();
                    $("#webcam-container").hide();
                    $("#webcam-capture-associate").attr("disabled", "disabled");
                    $("#webcam-start-associate").removeAttr("disabled");

                    if (data.FaceRecords && data.FaceRecords.length == 1) {
                        // Add Additional Face Data To DDB
                        var faceData = data.FaceRecords[0];
                        var personMetadata = {
                            username: $("#associate-username").val(),
                            hometown: $("#associate-hometown").val(),
                            animal: $("#associate-favouriteAnimal").val(),
                            date: "0"


                        };

                        var updateRequest =
                        {
                            "TableName": config.ddbTableName,
                            "Key":
                            {
                                "faceId": { "S": "" + faceData.Face.FaceId },
                            },
                            ExpressionAttributeNames: {},
                            ExpressionAttributeValues: {},
                            UpdateExpression: "",
                            ReturnValues: "ALL_NEW"
                        }

                        addExpressionForDDBUpdate(updateRequest, personMetadata, "username", "alias", "S");
                        addExpressionForDDBUpdate(updateRequest, personMetadata, "hometown", "hometown", "S");
                        addExpressionForDDBUpdate(updateRequest, personMetadata, "animal", "animal", "S");
                        addExpressionForDDBUpdate(updateRequest, personMetadata, "date", "date", "N");

                        if (faceData.FaceDetail) {
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.Gender, "Value", "gender", "S");
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.AgeRange, "Low", "age_range_lo", "N");
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.AgeRange, "High", "age_range_hi", "N");
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.Eyeglasses, "Value", "eyeglasses", "B");
                        }

                        //
                        // Update DynamoDB
                        //
                        console.log("TEST")
                        console.log(updateRequest)
                        updateTextArea($('#response-area-associate-ddb-result'), "Updating DynamoDB...");
                        new AWS.DynamoDB().updateItem(
                            updateRequest,
                            function (err, data) {
                                if (err != null) {
                                    updateTextArea($('#response-area-associate-ddb-result'), "ERROR: " + JSON.stringify(err));
                                }
                                else {
                                    updateTextArea($('#response-area-associate-ddb-result'), "OK: " + JSON.stringify(data));
                                    //console.log(data);
                                }
                            });
                    }

                });

           // });
        }
        else {
            showDialog("Missing information", "Please provide information to associate with your face. You need to provide your name, home town and favourite animal.");
        }
    });



    $("#webcam-start-scan").click(function (event) {
        event.preventDefault();
        updateTextArea($('#response-area-scan'), "STARTING: Periodic table update");

        $("#tableFaces").show();
        $("#response-area-scan").show();
        $("#webcam-start-scan").hide();

        setTimeout(refreshTable, 1000);
    });

    var rekognition = null;
    AWS.config.region = config.region;

    $(document).ready(function ($) {

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId: config.cognitoIdentityPoolId
        });

        rekognition = new AWS.Rekognition();
    });

    function showDialog(header, body) {
        $("#modalDialogHeader").html(header);
        $("#modalDialogBody").html(body);
        $("#modalDialog").modal();
    }
});


function refreshTable() {
    var scanRequest =
    {
        "TableName": config.ddbTableName
    }

    updateTextArea($('#response-area-scan'), "SCANNING: DynamoDB Table...");
    new AWS.DynamoDB().scan(
        scanRequest,
        function (err, data) {
            if (err != null) {
                updateTextArea($('#response-area-scan'), "ERROR: " + JSON.stringify(err));
            }
            else {
                updateTextArea($('#response-area-scan'), "OK: " + JSON.stringify(data));

                $("#tableFaces > tbody").empty();

                for (var item in data.Items) {
                    var thisItem = data.Items[item];

                    var now = new Date().getTime();
                    var date = thisItem.date ? new Date(parseInt(thisItem.date.N)) : 0;
                    var reldate = date > 0 ? getRelativeTime(now, date) : { ageLabelType: "danger", words: "never" };
                    var username = thisItem.alias.S;
                    var loc = thisItem.location ? thisItem.location.S : "Unknown";
                    var age = ~~((~~thisItem.age_range_hi.N - ~~thisItem.age_range_lo.N) / 2) + ~~thisItem.age_range_lo.N;
                    var sentiment = thisItem.sentiment ? thisItem.sentiment.S : "Unknown";
                    var markup = "<tr><td>" + username + "</td><td>" + loc + "</td><td>" + age + "</td><td>" + sentiment + "</td><td><span class=\"label label-" + reldate.ageLabelType + "\">" + reldate.words + "</td></tr>";
                    $("#tableFaces").append(markup);
                }
            }

            setTimeout(refreshTable, 5000);

        });
}



