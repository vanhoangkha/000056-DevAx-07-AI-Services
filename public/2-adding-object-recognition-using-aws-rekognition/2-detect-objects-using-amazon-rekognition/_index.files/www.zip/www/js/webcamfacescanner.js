
    var webcamElement = null;
    var canvasElement = null;
    var webcam = null;
    var data_uri = null;

$(document).ready(function ($) {



    // const webcamElement = document.getElementById('webcamRecognize');
    // const canvasElement = document.getElementById('canvas1');
    // const webcam1 = new Webcam(webcamElement, 'user1', canvasElement, null);

    $("#webcam-start-recognise").click(function (event) {
        event.preventDefault();
        webcamElement = document.getElementById('webcamRecognize');
        canvasElement = document.getElementById('canvas');
        webcam = new Webcam(webcamElement, 'user', canvasElement, null);

        webcam.start()
            .then(result => {
                console.log("webcam started");
                setTimeout(recogniseFace, 1000);
            })
            .catch(err => {
                console.log(err);
            });
            
        $("#webcam-recognise-container").show();
        $("#webcam-start-recognise").attr("disabled", "disabled");
    });

   // $("#webcam-capture-associate").attr("disabled", "disabled");
    $("#webcam-start-associate").click(function (event) {

        event.preventDefault();
        
        webcamElement = document.getElementById('webcamCollection');
        canvasElement = document.getElementById('canvas1');
        webcam = new Webcam(webcamElement, 'user', canvasElement, null);

        webcam.start()
            .then(result => {
                console.log("webcam started");
            })
            .catch(err => {
                console.log(err);
            });

        $("#webcam-container").show();
        $("#webcam-start-associate").attr("disabled", "disabled");
        $("#webcam-capture-associate").removeAttr("disabled");
    });

    $("#webcam-capture-associate").click(function (event) {

        //
        // If all fields have data, we can grab the image
        //

        event.preventDefault();

        $("#webcam-capture-associate").attr("disabled", "disabled");
        var readyToSubmit = (
            $("#associate-favouriteAnimal").val() != "" &&
            $("#associate-favouriteAnimal").val() != null &&
            $("#associate-hometown").val() != "" &&
            $("#associate-username").val() != ""
        );

        if (readyToSubmit) {
            updateTextArea($('#response-area-associate-result'), "Submitting image...");


            data_uri = webcam.snap();

            var params =
            {
                CollectionId: config.rekognitionCollectionId,
                DetectionAttributes: ["ALL", "DEFAULT"],
                ExternalImageId: "" + new Date().getTime(),
                Image:
                {
                    Bytes: dataURItoBlob(data_uri)
                }
            };

            new AWS.Rekognition().indexFaces(params, function (err, data) {
                if (err) {
                    updateTextArea($('#response-area-associate-result'), JSON.stringify(err));
                }
                else {
                    updateTextArea($('#response-area-associate-result'), JSON.stringify(data));

                    if (data.FaceRecords && data.FaceRecords.length == 1) {
                        // Add Additional Face Data To DDB
                        var faceData = data.FaceRecords[0];
                        var personMetadata = {
                            username: $("#associate-username").val(),
                            hometown: $("#associate-hometown").val(),
                            animal: $("#associate-favouriteAnimal").val(),
                            date: "0"
                        };

                        var updateRequest =
                        {
                            "TableName": config.ddbTableName,
                            "Key":
                            {
                                "faceId": { "S": "" + faceData.Face.FaceId },
                            },
                            ExpressionAttributeNames: {},
                            ExpressionAttributeValues: {},
                            UpdateExpression: "",
                            ReturnValues: "ALL_NEW"
                        }

                        addExpressionForDDBUpdate(updateRequest, personMetadata, "username", "alias", "S");
                        addExpressionForDDBUpdate(updateRequest, personMetadata, "hometown", "hometown", "S");
                        addExpressionForDDBUpdate(updateRequest, personMetadata, "animal", "animal", "S");
                        addExpressionForDDBUpdate(updateRequest, personMetadata, "date", "date", "N");

                        if (faceData.FaceDetail) {
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.Gender, "Value", "gender", "S");
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.AgeRange, "Low", "age_range_lo", "N");
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.AgeRange, "High", "age_range_hi", "N");
                            addExpressionForDDBUpdate(updateRequest, faceData.FaceDetail.Eyeglasses, "Value", "eyeglasses", "B");
                        }

                        //
                        // Update DynamoDB
                        //
                        console.log(updateRequest)
                        updateTextArea($('#response-area-associate-ddb-result'), "Updating DynamoDB...");
                        new AWS.DynamoDB().updateItem(
                            updateRequest,
                            function (err, data) {
                                if (err != null) {
                                    updateTextArea($('#response-area-associate-ddb-result'), "ERROR: " + JSON.stringify(err));
                                }
                                else {
                                    updateTextArea($('#response-area-associate-ddb-result'), "OK: " + JSON.stringify(data));
                                    //console.log(data);
                                }
                            });
                    }
                }

                webcam.stop();
                $("#webcam-container").hide();
                $("#webcam-capture-associate").attr("disabled", "disabled");
                $("#webcam-start-associate").removeAttr("disabled");

            });
        }
        else {
            showDialog("Missing information", "Please provide information to associate with your face. You need to provide your name, home town and favourite animal.");
        }
    });
});


function recogniseFace() {
    data_uri = webcam.snap();

    var params =
    {
        CollectionId: config.rekognitionCollectionId,
        FaceMatchThreshold: config.faceMatchThreshold,
        MaxFaces: 1,
        Image:
        {
            Bytes: dataURItoBlob(data_uri)
        }
    };

    rekognition.searchFacesByImage(params, function (err, data) {
        if (err) {
            updateTextArea($('#response-area-recognise-result'), "ERROR: " + JSON.stringify(err));
            setTimeout(recogniseFace, 3000);
        }
        else {
            if (data.FaceMatches && data.FaceMatches.length == 1) {
                var thisFace = data.FaceMatches[0];
                updateTextArea($('#response-area-recognise-result'), JSON.stringify(thisFace));

                $("#recognised-faceId").val(thisFace.Face.FaceId)
                $("#recognised-date").val(new Date(parseInt(thisFace.Face.ExternalImageId)))

                var queryRequest =
                {
                    "TableName": config.ddbTableName,
                    KeyConditionExpression: "#faceId = :faceId",
                    ExpressionAttributeNames: {
                        "#faceId": "faceId"
                    },
                    ExpressionAttributeValues: {
                        ":faceId": { "S": thisFace.Face.FaceId }
                    }
                }

                updateTextArea($('#response-area-recognise-ddb-result'), "Retrieving additional information for FaceId " + thisFace.Face.FaceId);
                new AWS.DynamoDB().query(
                    queryRequest,
                    function (err, data) {
                        if (err != null) {
                            updateTextArea($('#response-area-recognise-ddb-result'), "ERROR: " + JSON.stringify(err));
                        }
                        else {
                            updateTextArea($('#response-area-recognise-ddb-result'), "OK: " + JSON.stringify(data));

                            if (data.Items && data.Items[0]) {
                                $("#recognised-username").val(data.Items[0].alias ? data.Items[0].alias.S : "Anonymous face");
                                $("#recognised-hometown").val(data.Items[0].hometown ? data.Items[0].hometown.S : "");
                                $("#recognised-animal").val(data.Items[0].animal ? data.Items[0].animal.S : "");
                                $("#recognised-gender").html(data.Items[0].gender ? data.Items[0].gender.S : "");
                            }
                            else {
                                $("#recognised-username").val("Anonymous face");
                            }
                        }

                        setTimeout(recogniseFace, 1000);

                    });
            }
            else {
                updateTextArea($('#response-area-recognise-result'), "No faces recognised - waiting 3 seconds...");
                setTimeout(recogniseFace, 3000);
            }
        }
    });

    // });
}