$(document).ready(function ($) {

    AWS.config.region = config.region;

    AWS.config.credentials = new AWS.CognitoIdentityCredentials({
        IdentityPoolId: config.cognitoIdentityPoolId
    });

    $("#webcam-start-detector").click(function (event) {
        event.preventDefault();
        webcamElement = document.getElementById('webcamDetector');
        canvasElement = document.getElementById('canvas');
        webcam = new Webcam(webcamElement, 'user', canvasElement, null);

        webcam.start()
            .then(result => {
                console.log("webcam started");
                setTimeout(grabImageFromWebcamAndUpload, 1000);
            })
            .catch(err => {
                console.log(err);
            });
        $("#webcam-detector-container").show();
        $("#webcam-start-detector").attr("disabled", "disabled");

     
    });

});

function showDialog(header, body) {
    $("#modalDialogHeader").html(header);
    $("#modalDialogBody").html(body);
    $("#modalDialog").modal();
}

function grabImageFromWebcamAndUpload() {
   // Webcam.snap(function (data_uri) {


        data_uri = webcam.snap();


        var objectKey = $("#detector-location").val().replace(/[^-a-zA-Z0-9]+/, "-") + "." + new Date().getTime() + ".jpg";
        updateTextArea($('#response-area-upload-result'), "UPLOADING: Sending image data to S3 as " + objectKey);

        var s3 = new AWS.S3.ManagedUpload(
            {
                params: {
                    Bucket: config.detectorUploadBucket,
                    Key: objectKey,
                    Body: dataURItoBlob(data_uri),
                    Metadata: {
                        "idevelop-location": $("#detector-location").val(),
                        "idevelop-date": "" + new Date().getTime()
                    }
                }
            }).
            on('httpUploadProgress', function (evt) {
                updateTextArea($('#response-area-upload-result'), "PROGRESS: " + evt.loaded + "/" + evt.total);

            }).send(function (err, data) {
                if (err) {
                    updateTextArea($('#response-area-upload-result'), "ERROR: " + JSON.stringify(err));
                    console.log(err)
                }
                else {
                    updateTextArea($('#response-area-upload-result'), "DONE: Image file has been uploaded. Next image in 3 seconds...");

                    setTimeout(grabImageFromWebcamAndUpload, 3000);
                }
            });
   // });
}
