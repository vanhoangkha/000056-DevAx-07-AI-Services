
$("#startRekButton").click(startReckognition);

AWS.config.region = config.region;
var rekognition = null;


const webcamElement = document.getElementById('webcam');
const canvasElement = document.getElementById('canvas');
const webcam = new Webcam(webcamElement, 'user', canvasElement, null);

function startReckognition( event ) {
  event.preventDefault();

  $("#startRekButton").attr("disabled", "disabled");
  $("#LabelResults").append('<h3><span class="label label-default">Connecting...</span></h3>');

  AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: config.cognitoIdentityPoolId
  });

  rekognition = new AWS.Rekognition();


  webcam.start()
    .then(result => {
      console.log("webcam started");

      getAndListLabels();
    })
    .catch(err => {
      console.log(err);
    });

}


function getAndListLabels() {
  let data_uri = webcam.snap();
  var imageBlob = dataURItoBlob(data_uri);

  var params = {
    Image: {
      Bytes: imageBlob
    },
    MaxLabels: 10,
    MinConfidence: 50
  };
  rekognition.detectLabels(params, function (err, data) {
    if (err) console.log(err, err.stack); // an error occurred
    else {
      $("#LabelResults").empty();
      var labelTemplate = '<span style="font-size: 14px;" class="label label-success"><span class="rekLabel"></span> <span class="badge"><span class="rekScore"></span>%</span></span><br/><br/>';

      $.each(data.Labels, function (index, value) {

        var LabelToAdd = $(labelTemplate);
        $(LabelToAdd).find(".rekLabel").text(value.Name);
        $(LabelToAdd).find(".rekScore").text(Math.floor(value.Confidence));
        $("#LabelResults").append(LabelToAdd);
      });
      setTimeout(function () { getAndListLabels(); }, 500);
    }
  });
}

function dataURItoBlob(dataURI) {
  var binary = atob(dataURI.split(',')[1]);
  var array = [];
  for (var i = 0; i < binary.length; i++) {
    array.push(binary.charCodeAt(i));
  }
  return new Uint8Array(array);
}
