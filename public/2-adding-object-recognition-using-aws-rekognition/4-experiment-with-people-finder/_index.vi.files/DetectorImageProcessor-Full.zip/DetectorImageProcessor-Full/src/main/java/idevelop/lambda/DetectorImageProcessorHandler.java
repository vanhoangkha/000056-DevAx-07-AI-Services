package idevelop.lambda;

import java.math.BigDecimal;
import java.util.List;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.UpdateItemOutcome;
import com.amazonaws.services.dynamodbv2.document.spec.UpdateItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.NameMap;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.Attribute;
import com.amazonaws.services.rekognition.model.DetectFacesRequest;
import com.amazonaws.services.rekognition.model.DetectFacesResult;
import com.amazonaws.services.rekognition.model.Emotion;
import com.amazonaws.services.rekognition.model.FaceDetail;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.S3Object;
import com.amazonaws.services.rekognition.model.SearchFacesByImageRequest;
import com.amazonaws.services.rekognition.model.SearchFacesByImageResult;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.internal.DeleteObjectsResponse;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.DeleteObjectsRequest;
import com.amazonaws.services.s3.model.DeleteObjectsResult;
import com.amazonaws.services.s3.model.GetObjectMetadataRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;

public class DetectorImageProcessorHandler implements RequestHandler<S3Event, Void> 
{
	private AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
	private DynamoDB dynamoDB = new DynamoDB(client);
	private AmazonS3 s3 = AmazonS3ClientBuilder.standard().build();
	private AmazonRekognition rekognition = AmazonRekognitionClientBuilder.standard().build();
	private String collectionId = System.getenv("REKOGNITION_COLLECTION_ID");
	private String ddbTableName = System.getenv("DDB_TABLENAME_KNOWN_FACES");
	
	private final float FACE_MATCH_THRESHOLD = 90.0f;
	
	public Void handleRequest(S3Event event, Context context) 
	{				
		LambdaLogger logger = context.getLogger();
		
		logger.log("Starting " + this.getClass().getName() + " Lambda\n");
		
		if ( collectionId == null || collectionId == "" )
		{
			System.out.println("REKOGNITION_COLLECTION_ID envVar not set!");
		}
		else
		if ( ddbTableName == null || ddbTableName == "" )
		{
			System.out.println("DDB_TABLENAME_KNOWN_FACES envVar not set!");
		}
		else
		{
			try
			{			            
		        String bucket = event.getRecords().get(0).getS3().getBucket().getName();
		        String key = event.getRecords().get(0).getS3().getObject().getKey();
	
		        System.out.println(String.format(
		                "Processing for %s/%s", bucket, key));
	
		        //
		        // Get the metadata about the detection - used to update DDB
		        //
		        ObjectMetadata s3Metadata = s3.getObjectMetadata(new GetObjectMetadataRequest(bucket, key));
		        String detectorLocation = s3Metadata.getUserMetaDataOf("idevelop-location");
		        String detectionDate = s3Metadata.getUserMetaDataOf("idevelop-date");
		        
		        //
		        // Detect faces in the image. Assume only 1, for this demo...
		        //
		        DetectFacesRequest detectFacesRequest = new DetectFacesRequest()
		                .withImage(getImageUtil(bucket, key))
		                .withAttributes(Attribute.ALL);
	
		        System.out.println("Detecting faces in image...");
		        DetectFacesResult detectFacesResult = rekognition.detectFaces(detectFacesRequest);
		        System.out.println("     done");
		        List <FaceDetail> faceDetails = detectFacesResult.getFaceDetails();
		        
		        if ( faceDetails.size() > 0 )
		        {
		        		FaceDetail thisFace = faceDetails.get(0);	        		
		        		String thisFaceEmotions = "";
	
	                for ( Emotion emotion : thisFace.getEmotions() )
	                {
	                    if ( emotion.getConfidence() > 30 )
	                    {
	                        thisFaceEmotions += emotion.getType() + " ";
	                    }
	                }
	
	                if ( thisFaceEmotions == "")
	                {
	                    thisFaceEmotions = "(Indeterminate)";
	                }
	                
	                System.out.println("Face emotions -> " + thisFaceEmotions);
	                
	                SearchFacesByImageRequest searchFacesByImageRequest = new SearchFacesByImageRequest()
	                        .withCollectionId(collectionId)
	                        .withImage(getImageUtil(bucket, key))
	                        .withFaceMatchThreshold(FACE_MATCH_THRESHOLD)
	                        .withMaxFaces(1);

	                System.out.println("Calling searchFacesByImage()");
	                SearchFacesByImageResult searchFacesByImageResult =
	                		rekognition.searchFacesByImage(searchFacesByImageRequest);
	                System.out.println("     done");
	                
	                if ( searchFacesByImageResult.getFaceMatches().size() == 1)
	                {
	                		System.out.println("Got 1 face (as expected)");
	                		String faceId = searchFacesByImageResult.getFaceMatches().get(0).getFace().getFaceId();
	                		System.out.println("faceId -> " + faceId);
	                		
	                		//
	                		// Now we know the FaceId, and we have some Emotions, we update
	                		// the DynamoDB table with the new information
	                		//
	                		Table table = dynamoDB.getTable(ddbTableName);
	                		
	                		UpdateItemSpec updateItemSpec = new UpdateItemSpec().withPrimaryKey("faceId", faceId)
	                                .withReturnValues(ReturnValue.ALL_NEW)
	                                .withUpdateExpression("set #sn = :sn, #date = :date, #loc = :loc")
	                                .withNameMap(new NameMap()
	                                		.with("#sn",   "sentiment")
	                                		.with("#date", "date")
	                                		.with("#loc",  "location")
	                                		)
	                                //http://docs.aws.amazon.com/amazondynamodb/latest/developerguide/JavaDocumentAPICRUDExample.html
	                                .withConditionExpression("#date < :date")
	                                .withValueMap(new ValueMap()
	                                		.withString(":sn", thisFaceEmotions)
	                                		.withString(":loc", detectorLocation)
	                                		.withNumber(":date", new BigDecimal(detectionDate))
	                                		);

	                            UpdateItemOutcome outcome = table.updateItem(updateItemSpec);

	                            // Check the response.
	                            System.out.println("Printing item after conditional update to new attribute...");
	                            System.out.println(outcome.getItem().toJSONPretty());	                		
	                }
	                else
	                {
	                		System.out.println("No faces / too many faces recognised - exiting");
	                }
	                
		        }
		        else
		        {
		        		System.out.println("Found no faces in the image - exiting");
		        }
		        
                // Delete the original image
                System.out.println("Deleting the original file...");
                s3.deleteObjects(
                		new DeleteObjectsRequest(bucket)
                			.withKeys(key)
                			);
                System.out.println("     done");
		        
			}
			catch(Exception e)
			{
				String errorMessage = String.format(
		                "Error processing image"
		                );
				
				System.out.println(errorMessage);
				System.out.println(e.getMessage());
			}
			finally
			{
				System.out.println("Processing ends");
			}	
		}
		
		return null;		
	}

	private static Image getImageUtil(String bucket, String key) 
	{
       return new Image()
    		  	.withS3Object(new S3Object()
            .withBucket(bucket)
            .withName(key));
	}
}
